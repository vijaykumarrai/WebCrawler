package com.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.web.util.Util;

public class WebCrawlerApp {
	public static final String URL = "https://en.wikipedia.org/wiki/Microsoft";

	public static void main(String args[]) throws IOException {
		try {

			int outputCount = 10;
			// String excluded = "";
			Scanner in = new Scanner(System.in);
			BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter input values.");
			System.out.println("Please enter the value for the number of words to return (default : 10) ");
			String count = buffer.readLine();
			if (count != null && count.trim().length() > 0) {
				outputCount = Integer.parseInt(count.trim());
				if (outputCount == 0) {
					System.out.println("No result to display");
					System.exit(0);
				}
			}
			System.out.println(
					"Please enter the words to exclude from the search (Comma seperated list. e.g. :- Microsoft,Windows). Press Enter for empty value.");
			String excluded = buffer.readLine();

			System.out.println("\nResult : ");

			List<String> inputStringList;
			inputStringList = Util.getInputList(URL, excluded);

			Map<String, Long> map = inputStringList.stream()
					.collect(Collectors.groupingBy(w -> w, Collectors.counting()));
			List<Map.Entry<String, Long>> resultMap = map.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())).limit(outputCount)
					.collect(Collectors.toList());

			int i = 0;
			i++;

			for (Map.Entry<String, Long> entry : resultMap) {
				System.out.println(entry.getKey() + " 	: " + entry.getValue());
			}
		} catch (Exception e) {
			System.out.println("Exception while processing the request " + e);
		}
	}
}
