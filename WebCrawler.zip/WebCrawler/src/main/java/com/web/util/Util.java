package com.web.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class Util {
	private static final String ALPHA_NUMERIC = "[^\\p{IsAlphabetic}\\p{IsDigit}]";
	private static final String DELIM = " \n\r\t,.;";

	private static final String START_STRING = "History";
	private static final String END_STRING = "[124]";

	public static List<String> getInputList(String URL, String excluded) throws Exception {
		String input = "";
		try {
			Connection conn = Jsoup.connect(URL);
			Document doc = conn.get();
			input = doc.body().text();
		} catch (IOException e) {
			System.out.println("Exception while connecting to the URL");
		}

		Set<String> excludedSet = getExcludedSet(excluded);
		List<String> result = getStringTokens(input, excludedSet);

		return result;

	}

	public static List<String> getStringTokens(String input, Set<String> excluded) {
		List<String> stringList = new ArrayList<>();

		String delim = " \n\r\t,.;";
		StringTokenizer st = new StringTokenizer(input, DELIM);
		String previous = "";
		boolean start = false;

		while (st.hasMoreTokens()) {
			String value = st.nextToken().trim();

			if (value.equals(END_STRING)) {
				break;
			}
			value = value.replaceAll(ALPHA_NUMERIC, "");

			if (value.trim().equals("links"))
				previous = value;
			else if (previous.equals("links") && value.equals(START_STRING))
				start = true;
			else
				previous = "";

			if (start) {
				if (excluded.contains(value))
					continue;
				stringList.add(value);
			}
		}
		return stringList;
	}

	public static Set<String> getExcludedSet(String excluded) {
		String[] exclude = excluded.split(",");
		List<String> excludeList = Arrays.asList(exclude);
		Set<String> excludedSet = new HashSet<>(excludeList);

		return excludedSet;
	}
}
